<?php

if ( ! defined( 'ABSPATH' ) ) exit;

// Note: The functions render_question_bank_table() and render_users_table()
// have been replaced by the WP_List_Table classes:
// Practice_Test_Questions_List_Table in includes/admin/class-questions-list-table.php
// Practice_Test_Users_List_Table in includes/admin/class-users-list-table.php
// These old functions have been removed.

// Add any other future utility functions here.
